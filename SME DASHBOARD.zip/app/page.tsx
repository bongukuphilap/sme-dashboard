'use client';

import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
} from '@mui/material';
import {
  TrendingUp,
  People,
  Inventory,
  Receipt,
} from '@mui/icons-material';

const stats = [
  { title: 'Total Revenue', value: 'R 284,500', change: '+12.5%', icon: <TrendingUp />, color: '#1976d2' },
  { title: 'Customers', value: '1,248', change: '+8.2%', icon: <People />, color: '#2e7d32' },
  { title: 'Products', value: '342', change: '+3.1%', icon: <Inventory />, color: '#ed6c02' },
  { title: 'Pending Invoices', value: '47', change: '-2.4%', icon: <Receipt />, color: '#9c27b0' },
];

const recentInvoices = [
  { id: 'INV-001', customer: 'Acme Corp', amount: 'R 12,450', status: 'Paid', date: '2026-09-01' },
  { id: 'INV-002', customer: 'Tech Solutions', amount: 'R 8,200', status: 'Pending', date: '2026-09-02' },
  { id: 'INV-003', customer: 'Green Farms', amount: 'R 15,800', status: 'Paid', date: '2026-09-02' },
  { id: 'INV-004', customer: 'City Builders', amount: 'R 6,750', status: 'Overdue', date: '2026-08-28' },
];

export default function HomePage() {
  return (
    <Box sx={{ p: 4, bgcolor: 'background.default', minHeight: '100vh' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight="bold" color="text.primary">
            SME Dashboard
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Welcome back! Here&apos;s what&apos;s happening with your business today.
          </Typography>
        </Box>
        <Button variant="contained" color="primary">
          + New Invoice
        </Button>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {stats.map((stat) => (
          <Grid item xs={12} sm={6} md={3} key={stat.title}>
            <Card elevation={1}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {stat.title}
                    </Typography>
                    <Typography variant="h5" fontWeight="bold">
                      {stat.value}
                    </Typography>
                    <Typography
                      variant="caption"
                      sx={{ color: stat.change.startsWith('+') ? 'success.main' : 'error.main' }}
                    >
                      {stat.change} from last month
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      bgcolor: stat.color,
                      color: 'white',
                      p: 1.2,
                      borderRadius: 2,
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    {stat.icon}
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Card elevation={1}>
        <CardContent>
          <Typography variant="h6" fontWeight="600" gutterBottom>
            Recent Invoices
          </Typography>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: 'grey.50' }}>
                  <TableCell>Invoice</TableCell>
                  <TableCell>Customer</TableCell>
                  <TableCell>Amount</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Date</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {recentInvoices.map((row) => (
                  <TableRow key={row.id} hover>
                    <TableCell sx={{ fontWeight: 500 }}>{row.id}</TableCell>
                    <TableCell>{row.customer}</TableCell>
                    <TableCell>{row.amount}</TableCell>
                    <TableCell>
                      <Chip
                        label={row.status}
                        size="small"
                        color={
                          row.status === 'Paid'
                            ? 'success'
                            : row.status === 'Pending'
                            ? 'warning'
                            : 'error'
                        }
                      />
                    </TableCell>
                    <TableCell>{row.date}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          </CardContent>
      </Card>
    </Box>
  );
}
